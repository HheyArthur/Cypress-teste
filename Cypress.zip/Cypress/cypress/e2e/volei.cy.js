describe("Marcar aula de volei", () => {

    it('Acessar site das aulas de volei', () => {
        cy.visit("https://cloudgym.io/app/")
        cy.get('#email').type('arthurguimaraes087@gmail.com')
        cy.get('#password').type('17012000')
        cy.get('#loginButton').click()
        













    })
})